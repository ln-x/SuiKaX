<?php
require_once __DIR__ . '/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') err('Method not allowed', 405);

// Public endpoint — uses session lat/lon if available, otherwise Vienna defaults

define('DEFAULT_LAT', 48.2082);
define('DEFAULT_LON', 16.3738);

// ── Resolve coordinates ───────────────────────────────────────────────────────
$userId = $_SESSION['user_id'] ?? null;
$lat    = DEFAULT_LAT;
$lon    = DEFAULT_LON;

if ($userId) {
    $stmt = db()->prepare('SELECT default_lat, default_lon FROM users WHERE id = ?');
    $stmt->execute([$userId]);
    $row = $stmt->fetch();
    if ($row && $row['default_lat'] !== null) {
        $lat = (float)$row['default_lat'];
        $lon = (float)$row['default_lon'];
    }
}

$cacheKey  = round($lat, 2) . ',' . round($lon, 2);
$wxFile    = sys_get_temp_dir() . '/suika_wx_' . md5($cacheKey) . '.json';
$powerFile = sys_get_temp_dir() . '/suika_power_' . md5($cacheKey) . '.json';
$wxTtl     = 900;   // 15 min
$powerTtl  = 21600; // 6 hr

// ── HTTP helper ───────────────────────────────────────────────────────────────
function http_get_env($url) {
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 15,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_USERAGENT      => 'SuiKa-App/1.0',
            CURLOPT_SSL_VERIFYPEER => true,
        ]);
        $r = curl_exec($ch);
        curl_close($ch);
        return $r;
    }
    return @file_get_contents($url);
}

// ── Open-Meteo + CAMS ─────────────────────────────────────────────────────────
function fetch_weather($lat, $lon) {
    $wx = http_get_env(
        "https://api.open-meteo.com/v1/forecast?latitude={$lat}&longitude={$lon}" .
        "&current=temperature_2m,relative_humidity_2m,apparent_temperature,wind_speed_10m,surface_pressure" .
        "&daily=daylight_duration,sunshine_duration&timezone=auto&forecast_days=1"
    );
    $aq = http_get_env(
        "https://air-quality-api.open-meteo.com/v1/air-quality?latitude={$lat}&longitude={$lon}" .
        "&current=european_aqi,pm2_5,pm10,nitrogen_dioxide,ozone,sulphur_dioxide" .
        "&hourly=grass_pollen,birch_pollen,mugwort_pollen&timezone=auto&forecast_days=1"
    );

    $wxd = $wx ? json_decode($wx, true) : [];
    $aqd = $aq ? json_decode($aq, true) : [];

    $cur   = $wxd['current'] ?? [];
    $elev  = $wxd['elevation'] ?? null;
    $daily = $wxd['daily'] ?? [];

    // Current hour index for hourly pollen arrays
    $now     = new DateTimeImmutable('now', new DateTimeZone($wxd['timezone'] ?? 'UTC'));
    $hour    = (int)$now->format('G');
    $aqHourly = $aqd['hourly'] ?? [];
    $pollenCount = count($aqHourly['grass_pollen'] ?? [1]);
    $aqIdx   = min($hour, $pollenCount - 1);
    if ($aqIdx < 0) $aqIdx = 0;

    // Current AQI values from `current` block (not hourly)
    $aqCur = $aqd['current'] ?? [];

    return [
        'temp'          => round((float)($cur['temperature_2m'] ?? 0), 1),
        'feelsLike'     => round((float)($cur['apparent_temperature'] ?? 0), 1),
        'humidity'      => (int)round((float)($cur['relative_humidity_2m'] ?? 0)),
        'windSpeed'     => round((float)($cur['wind_speed_10m'] ?? 0), 1),
        'pressure'      => (int)round((float)($cur['surface_pressure'] ?? 1013)),
        'daylightSec'   => (int)round((float)($daily['daylight_duration'][0] ?? 0)),
        'sunshineSecRaw'=> (int)round((float)($daily['sunshine_duration'][0] ?? 0)),
        'elevation'     => $elev !== null ? (int)round((float)$elev) : null,
        'wxLat'         => isset($wxd['latitude'])  ? round((float)$wxd['latitude'],  2) : $lat,
        'wxLon'         => isset($wxd['longitude']) ? round((float)$wxd['longitude'], 2) : $lon,
        'aqLat'         => isset($aqd['latitude'])  ? round((float)$aqd['latitude'],  2) : $lat,
        'aqLon'         => isset($aqd['longitude']) ? round((float)$aqd['longitude'], 2) : $lon,
        'aqi'           => (int)($aqCur['european_aqi'] ?? 0),
        'pm25'          => (int)round((float)($aqCur['pm2_5'] ?? 0)),
        'pm10'          => (int)round((float)($aqCur['pm10'] ?? 0)),
        'no2'           => (int)round((float)($aqCur['nitrogen_dioxide'] ?? 0)),
        'o3'            => (int)round((float)($aqCur['ozone'] ?? 0)),
        'so2'           => (int)round((float)($aqCur['sulphur_dioxide'] ?? 0)),
        'grassPollen'   => round((float)($aqHourly['grass_pollen'][$aqIdx]  ?? 0), 1),
        'birchPollen'   => round((float)($aqHourly['birch_pollen'][$aqIdx]  ?? 0), 1),
        'mugwortPollen' => round((float)($aqHourly['mugwort_pollen'][$aqIdx] ?? 0), 1),
    ];
}

// ── NASA POWER ────────────────────────────────────────────────────────────────
function fetch_power($lat, $lon) {
    $now       = new DateTimeImmutable('now', new DateTimeZone('UTC'));
    $end       = $now->format('Ymd');
    $start     = $now->modify('-29 days')->format('Ymd');
    $histEnd   = $now->modify('-5 years')->format('Ymd');
    $histStart = $now->modify('-5 years')->modify('-29 days')->format('Ymd');

    $base = "https://power.larc.nasa.gov/api/temporal/daily/point?parameters=T2M,PRECTOTCORR&community=AG&longitude={$lon}&latitude={$lat}&format=JSON";
    $cur  = http_get_env("{$base}&start={$start}&end={$end}");
    $hist = http_get_env("{$base}&start={$histStart}&end={$histEnd}");

    $extract = function($raw) {
        if (!$raw) return ['t2m' => [], 'prec' => []];
        $d     = json_decode($raw, true);
        $props = $d['properties']['parameter'] ?? [];
        $t2m   = [];
        $prec  = [];
        foreach ($props['T2M'] ?? [] as $v) {
            if ($v > -900) $t2m[] = (float)$v;
        }
        foreach ($props['PRECTOTCORR'] ?? [] as $v) {
            if ($v > -900) $prec[] = (float)$v;
        }
        return ['t2m' => $t2m, 'prec' => $prec];
    };

    $c = $extract($cur);
    $h = $extract($hist);

    $mean = function($arr) {
        $n = count($arr);
        return $n ? array_sum($arr) / $n : 0.0;
    };
    $sum = function($arr) {
        return array_sum($arr);
    };

    $curMeanT  = $mean($c['t2m']);
    $histMeanT = $mean($h['t2m']);
    $curSumP   = $sum($c['prec']);
    $histSumP  = $sum($h['prec']);

    $anomalyT = round($curMeanT - $histMeanT, 1);
    $anomalyP = $histSumP > 0 ? (int)round((($curSumP - $histSumP) / $histSumP) * 100) : 0;

    return [
        'monthly30dMean' => round($curMeanT, 1),
        'anomaly'        => $anomalyT,
        'monthly30dSum'  => (int)round($curSumP),
        'pctVsAvg'       => $anomalyP,
    ];
}

// ── Description helpers (PHP 7.4 compatible — no match expression) ─────────────
function aqi_label($aqi) {
    if ($aqi <= 20)  return 'Good';
    if ($aqi <= 40)  return 'Fair';
    if ($aqi <= 60)  return 'Moderate';
    if ($aqi <= 80)  return 'Poor';
    if ($aqi <= 100) return 'Very Poor';
    return 'Extremely Poor';
}

function aqi_desc($aqi) {
    if ($aqi <= 20) return 'Air quality is excellent. No health concerns for any group.';
    if ($aqi <= 40) return 'Air quality is fair. Outdoor activities are fine for most people.';
    if ($aqi <= 60) return 'Moderate air quality. Sensitive individuals may want to limit prolonged outdoor exertion.';
    if ($aqi <= 80) return 'Poor air quality. Sensitive groups should limit outdoor activities.';
    return 'Very poor air quality. Most people should reduce outdoor activities.';
}

function pollen_severity($grains) {
    if ($grains <= 10) return 'Low';
    if ($grains <= 30) return 'Moderate';
    if ($grains <= 60) return 'High';
    return 'Very High';
}

function pollen_desc($type, $severity) {
    if ($severity === 'Low')      return "Low pollen levels from {$type}. Minimal impact for most people.";
    if ($severity === 'Moderate') return "Moderate pollen from {$type}. If you're sensitive, consider timing outdoor activities for early morning or after rain.";
    if ($severity === 'High')     return "High pollen from {$type}. Allergy sufferers should consider medication and limit time outdoors.";
    return "Very high pollen from {$type}. Strongly consider staying indoors and taking allergy medication.";
}

function pressure_level($hPa) {
    if ($hPa < 1000)  return 'Low';
    if ($hPa > 1020)  return 'High';
    return 'Normal';
}

function pressure_desc($hPa) {
    if ($hPa < 1000) return "Low pressure system. Some people experience headaches, fatigue, or joint discomfort during low pressure conditions.";
    if ($hPa > 1020) return "High pressure system. Clear, stable conditions often associated with good weather and easy breathing.";
    return "Normal atmospheric pressure. Comfortable for most people. No significant pressure-related effects expected.";
}

function sultriness_level($humidity, $feelsLike) {
    if ($humidity > 75) return 'Very Sultry';
    if ($humidity > 60 && $feelsLike > 22) return 'Sultry';
    if ($humidity > 40 && $feelsLike > 22) return 'Slightly Sultry';
    return 'Comfortable';
}

function sultriness_desc($humidity, $feelsLike) {
    if ($humidity > 75) return 'Very sultry. High humidity significantly increases heat stress. Stay hydrated.';
    if ($humidity > 60 && $feelsLike > 22) return 'Sultry conditions. The combination of heat and humidity adds heat stress.';
    if ($humidity > 40 && $feelsLike > 22) return 'Moderate sultriness. Some heat-humidity discomfort may occur during activity.';
    return 'Not sultry. Humidity levels are comfortable and not adding to heat stress.';
}

function daylight_desc($pct) {
    if ($pct > 80) return 'Clear skies with abundant sunshine. Excellent conditions for outdoor activity and natural light exposure.';
    if ($pct > 60) return 'Mostly sunny with some cloud cover. Good natural light for mood and energy.';
    if ($pct > 40) return 'Partly cloudy. Moderate light exposure — consider outdoor breaks during clear spells.';
    return 'Overcast conditions. Limited natural light may affect mood and energy levels.';
}

function windchill_desc($diff) {
    if ($diff > 5) return 'Strong wind chill. Dress warmer than the actual temperature suggests.';
    if ($diff > 2) return 'Moderate wind chill. The wind makes it feel noticeably cooler.';
    if ($diff > -1) return 'Mild wind chill. A slight cooling effect from the wind, but nothing uncomfortable.';
    return 'No wind chill effect. The air feels warmer than the thermometer reads.';
}

function temp_desc($anomaly) {
    if ($anomaly > 3)  return 'Significantly warmer than usual. Heat may add to stress load on the nervous system.';
    if ($anomaly > 1)  return 'Above-average temperatures. Comfortable but warmer than the seasonal norm.';
    if ($anomaly > -1) return 'Temperatures are close to the local average. Comfortable conditions for activity and recovery.';
    if ($anomaly > -3) return 'Slightly below average temperatures. Cooler than the seasonal norm.';
    return 'Significantly cooler than usual for this time of year.';
}

function prec_desc($pct) {
    if ($pct > 30)  return 'Well above-normal precipitation. Wet conditions may limit outdoor activities.';
    if ($pct > 10)  return 'Slightly above normal precipitation for this period.';
    if ($pct > -10) return 'Precipitation is near normal levels for this area.';
    if ($pct > -30) return 'Drier than usual. Lower precipitation than typical for this time of year.';
    return 'Significantly drier than normal. Drought conditions may be developing.';
}

// ── Load / cache weather data ─────────────────────────────────────────────────
$now = time();
if (file_exists($wxFile) && ($now - filemtime($wxFile)) < $wxTtl) {
    $wx = json_decode(file_get_contents($wxFile), true);
} else {
    $wx = fetch_weather($lat, $lon);
    @file_put_contents($wxFile, json_encode($wx));
}

if (file_exists($powerFile) && ($now - filemtime($powerFile)) < $powerTtl) {
    $pw = json_decode(file_get_contents($powerFile), true);
} else {
    $pw = fetch_power($lat, $lon);
    @file_put_contents($powerFile, json_encode($pw));
}

// ── Build response ────────────────────────────────────────────────────────────
$daylightSec  = (int)($wx['daylightSec'] ?? 0);
$sunshineRaw  = (int)($wx['sunshineSecRaw'] ?? 0);
$sunshinePct  = $daylightSec > 0 ? (int)min(100, round(($sunshineRaw / $daylightSec) * 100)) : 0;
$sunshineSec  = min($sunshineRaw, $daylightSec);

$meta_wx = ['source' => 'Open-Meteo',         'grid' => '~1 km, interpolated to point', 'lat' => $wx['wxLat'], 'lon' => $wx['wxLon'], 'elevation' => $wx['elevation']];
$meta_aq = ['source' => 'Copernicus CAMS',     'grid' => '~11 km (CAMS Europe)',          'lat' => $wx['aqLat'], 'lon' => $wx['aqLon'], 'elevation' => null];
$meta_pw = ['source' => 'NASA POWER',          'grid' => '~0.5°×0.5° (~55 km)',           'lat' => $lat,         'lon' => $lon,         'elevation' => null];

$sultrinessLvl = sultriness_level($wx['humidity'], $wx['feelsLike']);
$pressureLvl   = pressure_level($wx['pressure']);
$aqi           = (int)($wx['aqi'] ?? 0);
$aqiLbl        = aqi_label($aqi);
$diff          = (float)$wx['temp'] - (float)$wx['feelsLike'];

// Dominant pollen
$pollenMap = [
    'Grass'   => (float)($wx['grassPollen']   ?? 0),
    'Birch'   => (float)($wx['birchPollen']   ?? 0),
    'Mugwort' => (float)($wx['mugwortPollen'] ?? 0),
];
arsort($pollenMap);
reset($pollenMap);
$dominant    = key($pollenMap);
$dominantVal = current($pollenMap);
$pollenSev   = pollen_severity($dominantVal);

$response = [
    'daylight' => [
        'daylightSec'     => $daylightSec,
        'sunshineSec'     => $sunshineSec,
        'sunshinePercent' => $sunshinePct,
        'description'     => daylight_desc($sunshinePct),
        'meta'            => $meta_wx,
    ],
    'windChill' => [
        'feelsLike'   => (float)$wx['feelsLike'],
        'actualTemp'  => (float)$wx['temp'],
        'windSpeed'   => (float)$wx['windSpeed'],
        'description' => windchill_desc($diff),
        'meta'        => $meta_wx,
    ],
    'sultriness' => [
        'feelsLike'   => (float)$wx['feelsLike'],
        'actualTemp'  => (float)$wx['temp'],
        'humidity'    => (int)$wx['humidity'],
        'level'       => $sultrinessLvl,
        'description' => sultriness_desc($wx['humidity'], $wx['feelsLike']),
        'meta'        => $meta_wx,
    ],
    'pressure' => [
        'hPa'         => (int)$wx['pressure'],
        'level'       => $pressureLvl,
        'description' => pressure_desc($wx['pressure']),
        'meta'        => $meta_wx,
    ],
    'airQuality' => [
        'aqi'         => $aqi,
        'aqiLabel'    => $aqiLbl,
        'pm25'        => (int)($wx['pm25'] ?? 0),
        'pm10'        => (int)($wx['pm10'] ?? 0),
        'no2'         => (int)($wx['no2']  ?? 0),
        'o3'          => (int)($wx['o3']   ?? 0),
        'so2'         => (int)($wx['so2']  ?? 0),
        'description' => aqi_desc($aqi),
        'meta'        => $meta_aq,
    ],
    'pollen' => $dominantVal > 0 ? [
        'dominant'    => $dominant,
        'grains'      => round($dominantVal, 0),
        'severity'    => $pollenSev,
        'description' => pollen_desc($dominant, $pollenSev),
        'meta'        => $meta_aq,
    ] : null,
    'temperature' => [
        'monthly30dMean' => (float)($pw['monthly30dMean'] ?? 0),
        'anomaly'        => (float)($pw['anomaly'] ?? 0),
        'description'    => temp_desc($pw['anomaly'] ?? 0),
        'meta'           => $meta_pw,
    ],
    'precipitation' => [
        'monthly30dSum' => (int)($pw['monthly30dSum'] ?? 0),
        'pctVsAvg'      => (int)($pw['pctVsAvg'] ?? 0),
        'description'   => prec_desc($pw['pctVsAvg'] ?? 0),
        'meta'          => $meta_pw,
    ],
];

ok($response);
