<?php
require_once __DIR__ . '/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') err('Method not allowed', 405);

// Public endpoint — uses session lat/lon if available, otherwise Vienna defaults

define('DEFAULT_LAT', 48.2082);
define('DEFAULT_LON', 16.3738);

// ── Resolve coordinates ───────────────────────────────────────────────────────
$userId = $_SESSION['user_id'] ?? null;
$lat    = DEFAULT_LAT;
$lon    = DEFAULT_LON;

if ($userId) {
    $stmt = db()->prepare('SELECT default_lat, default_lon FROM users WHERE id = ?');
    $stmt->execute([$userId]);
    $row = $stmt->fetch();
    if ($row && $row['default_lat'] !== null) {
        $lat = (float)$row['default_lat'];
        $lon = (float)$row['default_lon'];
    }
}

$cacheKey  = round($lat, 2) . ',' . round($lon, 2);
$wxFile    = sys_get_temp_dir() . '/suika_wx_' . md5($cacheKey) . '.json';
$powerFile = sys_get_temp_dir() . '/suika_power_' . md5($cacheKey) . '.json';
$wxTtl     = 900;   // 15 min
$powerTtl  = 21600; // 6 hr

// ── HTTP helper ───────────────────────────────────────────────────────────────
function http_get_env(string $url): string|false {
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 15,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_USERAGENT      => 'SuiKa-App/1.0',
            CURLOPT_SSL_VERIFYPEER => true,
        ]);
        $r = curl_exec($ch);
        curl_close($ch);
        return $r;
    }
    return @file_get_contents($url);
}

// ── Open-Meteo + CAMS ─────────────────────────────────────────────────────────
function fetch_weather(float $lat, float $lon): array {
    $wx = http_get_env(
        "https://api.open-meteo.com/v1/forecast?latitude={$lat}&longitude={$lon}" .
        "&current=temperature_2m,relative_humidity_2m,apparent_temperature,wind_speed_10m,surface_pressure" .
        "&daily=daylight_duration,sunshine_duration&timezone=auto&forecast_days=1"
    );
    $aq = http_get_env(
        "https://air-quality-api.open-meteo.com/v1/air-quality?latitude={$lat}&longitude={$lon}" .
        "&hourly=european_aqi,pm2_5,pm10,nitrogen_dioxide,ozone,sulphur_dioxide," .
        "grass_pollen,birch_pollen,mugwort_pollen&timezone=auto&forecast_days=1&forecast_hours=24"
    );

    $wxd = $wx ? json_decode($wx, true) : [];
    $aqd = $aq ? json_decode($aq, true) : [];

    $cur = $wxd['current'] ?? [];
    $elev = $wxd['elevation'] ?? null;
    $daily = $wxd['daily'] ?? [];

    // Current hour index for air quality arrays
    $now = new DateTimeImmutable('now', new DateTimeZone($wxd['timezone'] ?? 'UTC'));
    $hour = (int)$now->format('G');
    $aqHourly = $aqd['hourly'] ?? [];
    $aqIdx = min($hour, count($aqHourly['european_aqi'] ?? [1]) - 1);

    return [
        'temp'        => round((float)($cur['temperature_2m'] ?? 0), 1),
        'feelsLike'   => round((float)($cur['apparent_temperature'] ?? 0), 1),
        'humidity'    => round((float)($cur['relative_humidity_2m'] ?? 0)),
        'windSpeed'   => round((float)($cur['wind_speed_10m'] ?? 0), 1),
        'pressure'    => round((float)($cur['surface_pressure'] ?? 1013)),
        'daylightSec' => round((float)($daily['daylight_duration'][0] ?? 0)),
        'sunshineSecRaw' => round((float)($daily['sunshine_duration'][0] ?? 0)),
        'elevation'   => $elev !== null ? round((float)$elev) : null,
        'aqi'         => (int)($aqHourly['european_aqi'][$aqIdx] ?? 0),
        'pm25'        => round((float)($aqHourly['pm2_5'][$aqIdx] ?? 0), 1),
        'pm10'        => round((float)($aqHourly['pm10'][$aqIdx] ?? 0), 1),
        'no2'         => round((float)($aqHourly['nitrogen_dioxide'][$aqIdx] ?? 0), 1),
        'o3'          => round((float)($aqHourly['ozone'][$aqIdx] ?? 0), 1),
        'so2'         => round((float)($aqHourly['sulphur_dioxide'][$aqIdx] ?? 0), 1),
        'grassPollen' => round((float)($aqHourly['grass_pollen'][$aqIdx] ?? 0), 1),
        'birchPollen' => round((float)($aqHourly['birch_pollen'][$aqIdx] ?? 0), 1),
        'mugwortPollen' => round((float)($aqHourly['mugwort_pollen'][$aqIdx] ?? 0), 1),
        'wxSource'    => 'Open-Meteo',
        'aqSource'    => 'Copernicus CAMS via Open-Meteo',
        'wxGrid'      => '~1 km grid',
        'aqGrid'      => '~11 km grid',
    ];
}

// ── NASA POWER ────────────────────────────────────────────────────────────────
function fetch_power(float $lat, float $lon): array {
    $now   = new DateTimeImmutable('now', new DateTimeZone('UTC'));
    $end   = $now->format('Ymd');
    $start = $now->modify('-29 days')->format('Ymd');

    $histEnd   = $now->modify('-5 years')->format('Ymd');
    $histStart = $now->modify('-5 years')->modify('-29 days')->format('Ymd');

    $base = "https://power.larc.nasa.gov/api/temporal/daily/point?parameters=T2M,PRECTOTCORR&community=AG&longitude={$lon}&latitude={$lat}&format=JSON";
    $cur  = http_get_env("{$base}&start={$start}&end={$end}");
    $hist = http_get_env("{$base}&start={$histStart}&end={$histEnd}");

    $extract = function(string|false $raw): array {
        if (!$raw) return ['t2m' => [], 'prec' => []];
        $d = json_decode($raw, true);
        $props = $d['properties']['parameter'] ?? [];
        return [
            't2m'  => array_values(array_filter($props['T2M'] ?? [], fn($v) => $v > -900)),
            'prec' => array_values(array_filter($props['PRECTOTCORR'] ?? [], fn($v) => $v > -900)),
        ];
    };

    $c = $extract($cur);
    $h = $extract($hist);

    $mean = fn(array $arr) => count($arr) ? array_sum($arr) / count($arr) : 0.0;
    $sum  = fn(array $arr) => array_sum($arr);

    $curMeanT   = $mean($c['t2m']);
    $histMeanT  = $mean($h['t2m']);
    $curSumP    = $sum($c['prec']);
    $histSumP   = $sum($h['prec']);

    $anomalyT = round($curMeanT - $histMeanT, 1);
    $anomalyP = $histSumP > 0 ? round((($curSumP - $histSumP) / $histSumP) * 100) : 0;

    return [
        'monthly30dMean' => round($curMeanT, 1),
        'anomaly'        => $anomalyT,
        'monthly30dSum'  => round($curSumP, 1),
        'pctVsAvg'       => $anomalyP,
        'source'         => 'NASA POWER',
        'grid'           => '~55 km grid (0.5°×0.5°)',
    ];
}

// ── AQI helpers ───────────────────────────────────────────────────────────────
function aqi_label(int $aqi): string {
    if ($aqi <= 20)  return 'Good';
    if ($aqi <= 40)  return 'Fair';
    if ($aqi <= 60)  return 'Moderate';
    if ($aqi <= 80)  return 'Poor';
    if ($aqi <= 100) return 'Very Poor';
    return 'Extremely Poor';
}

function pollen_severity(float $grains): string {
    if ($grains < 10)  return 'Low';
    if ($grains < 30)  return 'Moderate';
    if ($grains < 100) return 'High';
    return 'Very High';
}

function pressure_level(float $hPa): string {
    if ($hPa < 1000)  return 'Low';
    if ($hPa <= 1020) return 'Normal';
    return 'High';
}

function sultriness_level(float $feelsLike, float $humidity): string {
    if ($humidity < 50 || $feelsLike < 24)  return 'Comfortable';
    if ($humidity < 65 || $feelsLike < 28)  return 'Slightly Sultry';
    if ($humidity < 80 || $feelsLike < 32)  return 'Sultry';
    return 'Very Sultry';
}

// ── Load / cache weather data ─────────────────────────────────────────────────
$now = time();
if (file_exists($wxFile) && ($now - filemtime($wxFile)) < $wxTtl) {
    $wx = json_decode(file_get_contents($wxFile), true);
} else {
    $wx = fetch_weather($lat, $lon);
    @file_put_contents($wxFile, json_encode($wx));
}

if (file_exists($powerFile) && ($now - filemtime($powerFile)) < $powerTtl) {
    $pw = json_decode(file_get_contents($powerFile), true);
} else {
    $pw = fetch_power($lat, $lon);
    @file_put_contents($powerFile, json_encode($pw));
}

// ── Build response ────────────────────────────────────────────────────────────
$daylightSec   = (int)$wx['daylightSec'];
$sunshineRaw   = (int)$wx['sunshineSecRaw'];
$sunshinePct   = $daylightSec > 0 ? round(($sunshineRaw / $daylightSec) * 100) : 0;
$sunshinePct   = min(100, $sunshinePct);
$sunshineSec   = min($sunshineRaw, $daylightSec);

$meta_wx = ['source' => $wx['wxSource'], 'grid' => $wx['wxGrid'], 'lat' => $lat, 'lon' => $lon, 'elevation' => $wx['elevation']];
$meta_aq = ['source' => $wx['aqSource'], 'grid' => $wx['aqGrid'], 'lat' => $lat, 'lon' => $lon, 'elevation' => null];
$meta_pw = ['source' => $pw['source'], 'grid' => $pw['grid'], 'lat' => $lat, 'lon' => $lon, 'elevation' => null];

$sultrinessLvl = sultriness_level($wx['feelsLike'], $wx['humidity']);
$pressureLvl   = pressure_level($wx['pressure']);
$aqiLbl        = aqi_label($wx['aqi']);

// Dominant pollen
$pollenMap = [
    'Grass'   => $wx['grassPollen'],
    'Birch'   => $wx['birchPollen'],
    'Mugwort' => $wx['mugwortPollen'],
];
arsort($pollenMap);
$dominant     = array_key_first($pollenMap);
$dominantVal  = $pollenMap[$dominant];
$pollenSev    = pollen_severity($dominantVal);

$response = [
    'daylight' => [
        'daylightSec'      => $daylightSec,
        'sunshineSec'      => $sunshineSec,
        'sunshinePercent'  => $sunshinePct,
        'description'      => "Today's daylight window is " . intdiv($daylightSec, 3600) . "h " . intdiv($daylightSec % 3600, 60) . "m. " . ($sunshinePct >= 70 ? "Bright and sunny." : ($sunshinePct >= 30 ? "Partly cloudy." : "Mostly overcast.")),
        'meta'             => $meta_wx,
    ],
    'windChill' => [
        'feelsLike'   => $wx['feelsLike'],
        'actualTemp'  => $wx['temp'],
        'windSpeed'   => $wx['windSpeed'],
        'description' => $wx['windSpeed'] >= 15
            ? "Wind at {$wx['windSpeed']} km/h is cooling the perceived temperature by " . round($wx['temp'] - $wx['feelsLike'], 1) . "°C."
            : "Light wind. Feels close to the actual temperature.",
        'meta' => $meta_wx,
    ],
    'sultriness' => [
        'feelsLike'   => $wx['feelsLike'],
        'actualTemp'  => $wx['temp'],
        'humidity'    => $wx['humidity'],
        'level'       => $sultrinessLvl,
        'description' => match($sultrinessLvl) {
            'Comfortable'    => "Low humidity ({$wx['humidity']}%) makes the air feel pleasant.",
            'Slightly Sultry'=> "Humidity at {$wx['humidity']}% adds a mild heaviness to the air.",
            'Sultry'         => "High humidity ({$wx['humidity']}%) makes it feel noticeably heavier than the thermometer reads.",
            default          => "Very high humidity ({$wx['humidity']}%) — intense sultry conditions. Sweating provides little relief.",
        },
        'meta' => $meta_wx,
    ],
    'pressure' => [
        'hPa'         => $wx['pressure'],
        'level'       => $pressureLvl,
        'description' => match($pressureLvl) {
            'Low'    => "Low pressure ({$wx['pressure']} hPa) often brings unsettled weather and can cause joint discomfort.",
            'High'   => "High pressure ({$wx['pressure']} hPa) typically means stable, fair weather.",
            default  => "Pressure at {$wx['pressure']} hPa — normal atmospheric conditions.",
        },
        'meta' => $meta_wx,
    ],
    'airQuality' => [
        'aqi'         => $wx['aqi'],
        'aqiLabel'    => $aqiLbl,
        'pm25'        => $wx['pm25'],
        'pm10'        => $wx['pm10'],
        'no2'         => $wx['no2'],
        'o3'          => $wx['o3'],
        'so2'         => $wx['so2'],
        'description' => $wx['aqi'] <= 20 ? "Air quality is excellent. Ideal for outdoor activity."
            : ($wx['aqi'] <= 40 ? "Air quality is fair. Suitable for most people."
            : ($wx['aqi'] <= 60 ? "Moderate air quality. Sensitive individuals should limit prolonged outdoor exposure."
            : "Poor air quality. Consider limiting outdoor activity today.")),
        'meta' => $meta_aq,
    ],
    'pollen' => [
        'dominant'    => $dominant,
        'grains'      => round($dominantVal, 1),
        'severity'    => $pollenSev,
        'description' => "{$dominant} pollen is dominant at {$dominantVal} grains/m³. " . match($pollenSev) {
            'Low'       => 'Low impact for most allergy sufferers.',
            'Moderate'  => 'Moderate levels — sensitive individuals may notice symptoms.',
            'High'      => 'High levels — allergy medication recommended.',
            default     => 'Very high — stay indoors if severely allergic.',
        },
        'meta' => $meta_aq,
    ],
    'temperature' => [
        'monthly30dMean' => $pw['monthly30dMean'],
        'anomaly'        => $pw['anomaly'],
        'description'    => "30-day mean temperature is {$pw['monthly30dMean']}°C. " . ($pw['anomaly'] > 0 ? "This is {$pw['anomaly']}°C above the 5-year average — warmer than usual." : ($pw['anomaly'] < 0 ? "This is " . abs($pw['anomaly']) . "°C below the 5-year average — cooler than usual." : "Close to the historical average.")),
        'meta'           => $meta_pw,
    ],
    'precipitation' => [
        'monthly30dSum' => $pw['monthly30dSum'],
        'pctVsAvg'      => $pw['pctVsAvg'],
        'description'   => "Total precipitation over the past 30 days: {$pw['monthly30dSum']} mm. " . ($pw['pctVsAvg'] >= 10 ? "Above average — {$pw['pctVsAvg']}% more than usual." : ($pw['pctVsAvg'] <= -10 ? abs($pw['pctVsAvg']) . "% below the historical average." : "Close to historical average.")),
        'meta'          => $meta_pw,
    ],
];

ok($response);
