<?php
require_once __DIR__ . '/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') err('Method not allowed', 405);

// Public endpoint — no auth required

$cacheFile = sys_get_temp_dir() . '/suika_earth_feeds.json';
$cacheTtl  = 1800;

if (file_exists($cacheFile) && (time() - filemtime($cacheFile)) < $cacheTtl) {
    $cached = file_get_contents($cacheFile);
    header('Content-Type: application/json; charset=utf-8');
    echo $cached;
    exit;
}

// ── HTTP helper ───────────────────────────────────────────────────────────────
function http_get($url) {
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 12,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_USERAGENT      => 'SuiKa-App/1.0 (burnout-recovery-companion)',
            CURLOPT_SSL_VERIFYPEER => true,
        ]);
        $result = curl_exec($ch);
        curl_close($ch);
        return $result;
    }
    return @file_get_contents($url);
}

// ── Type classifier (PHP 7.4 compatible — no str_contains) ────────────────────
function classify_type($title) {
    $t = strtolower($title);
    if (strpos($t, 'earthquake') !== false || strpos($t, 'seismic') !== false) return 'earthquake';
    if (strpos($t, 'flood') !== false)                                          return 'flood';
    if (strpos($t, 'storm') !== false || strpos($t, 'cyclone') !== false ||
        strpos($t, 'typhoon') !== false || strpos($t, 'hurricane') !== false)  return 'storm';
    if (strpos($t, 'volcano') !== false || strpos($t, 'volcanic') !== false)   return 'volcano';
    if (strpos($t, 'drought') !== false)                                        return 'drought';
    if (strpos($t, 'wildfire') !== false || strpos($t, 'fire') !== false)      return 'wildfire';
    if (strpos($t, 'tsunami') !== false)                                        return 'tsunami';
    if (strpos($t, 'epidemic') !== false || strpos($t, 'outbreak') !== false ||
        strpos($t, 'disease') !== false)                                        return 'epidemic';
    return 'other';
}

// ── USGS Significant Earthquakes ──────────────────────────────────────────────
function fetch_usgs() {
    $raw = http_get('https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/significant_week.geojson');
    if (!$raw) return ['items' => [], 'status' => 'error'];
    $data = json_decode($raw, true);
    $out  = [];
    foreach ($data['features'] ?? [] as $f) {
        $p        = $f['properties'] ?? [];
        $mag      = $p['mag'] ?? null;
        $place    = $p['place'] ?? 'Unknown location';
        $alert    = strtolower($p['alert'] ?? '');
        $title    = $p['title'] ?? ($mag ? "M {$mag} — {$place}" : $place);
        $severity = 'medium';
        if ($alert === 'red' || $alert === 'orange')  $severity = 'high';
        elseif ($alert === 'green')                    $severity = 'low';
        elseif ($mag !== null && (float)$mag >= 7.0)  $severity = 'high';
        $out[] = [
            'id'          => 'usgs-' . ($f['id'] ?? md5($title)),
            'title'       => $title,
            'type'        => 'earthquake',
            'severity'    => $severity,
            'source'      => 'USGS',
            'publishedAt' => isset($p['time']) ? gmdate('c', intval($p['time'] / 1000)) : gmdate('c'),
            'description' => $mag ? "Magnitude {$mag} — {$place}" : $place,
            'countries'   => [],
            'url'         => $p['url'] ?? null,
        ];
    }
    return ['items' => $out, 'status' => 'ok'];
}

// ── NWS Flood Alerts ──────────────────────────────────────────────────────────
function fetch_nws_floods() {
    $raw = http_get('https://api.weather.gov/alerts/active?event=Flood%20Warning,Flash%20Flood%20Warning,Flood%20Watch');
    if (!$raw) return ['items' => [], 'status' => 'error'];
    $data = json_decode($raw, true);
    $out  = [];
    foreach ($data['features'] ?? [] as $f) {
        $p        = $f['properties'] ?? [];
        $sev      = strtolower($p['severity'] ?? '');
        $severity = ($sev === 'extreme' || $sev === 'severe') ? 'high' : 'medium';
        $title    = ($p['headline'] ?? '') ?: (($p['event'] ?? '') ?: 'Flood Alert');
        $out[] = [
            'id'          => 'nws-flood-' . ($f['id'] ?? md5($title . ($p['sent'] ?? ''))),
            'title'       => $title,
            'type'        => 'flood',
            'severity'    => $severity,
            'source'      => 'NWS',
            'publishedAt' => $p['sent'] ?? gmdate('c'),
            'description' => $p['description'] ?? null,
            'countries'   => isset($p['areaDesc']) ? [$p['areaDesc']] : [],
            'url'         => 'https://www.weather.gov/alerts',
        ];
    }
    return ['items' => $out, 'status' => 'ok'];
}

// ── NWS Severe Weather ────────────────────────────────────────────────────────
function fetch_nws_storms() {
    $raw = http_get('https://api.weather.gov/alerts/active?event=Severe%20Thunderstorm%20Warning,Severe%20Thunderstorm%20Watch,Tornado%20Warning,Tornado%20Watch');
    if (!$raw) return ['items' => [], 'status' => 'error'];
    $data = json_decode($raw, true);
    $out  = [];
    foreach ($data['features'] ?? [] as $f) {
        $p        = $f['properties'] ?? [];
        $sev      = strtolower($p['severity'] ?? '');
        $severity = ($sev === 'extreme' || $sev === 'severe') ? 'high' : 'medium';
        $title    = ($p['headline'] ?? '') ?: (($p['event'] ?? '') ?: 'Severe Weather Alert');
        $out[] = [
            'id'          => 'nws-storm-' . ($f['id'] ?? md5($title . ($p['sent'] ?? ''))),
            'title'       => $title,
            'type'        => 'storm',
            'severity'    => $severity,
            'source'      => 'NWS',
            'publishedAt' => $p['sent'] ?? gmdate('c'),
            'description' => $p['description'] ?? null,
            'countries'   => isset($p['areaDesc']) ? [$p['areaDesc']] : [],
            'url'         => 'https://www.weather.gov/alerts',
        ];
    }
    return ['items' => $out, 'status' => 'ok'];
}

// ── NWS Tsunami Alerts ────────────────────────────────────────────────────────
function fetch_tsunami() {
    $raw = http_get('https://api.weather.gov/alerts/active?code=TSW,TSA,TSY');
    if (!$raw) return ['items' => [], 'status' => 'error'];
    $data = json_decode($raw, true);
    $out  = [];
    foreach ($data['features'] ?? [] as $f) {
        $p        = $f['properties'] ?? [];
        $sev      = strtolower($p['severity'] ?? '');
        $severity = ($sev === 'extreme' || $sev === 'severe') ? 'high' : 'medium';
        $title    = ($p['headline'] ?? '') ?: (($p['event'] ?? '') ?: 'Tsunami Alert');
        $out[] = [
            'id'          => 'nws-tsunami-' . ($f['id'] ?? md5($title . ($p['sent'] ?? ''))),
            'title'       => $title,
            'type'        => 'tsunami',
            'severity'    => $severity,
            'source'      => 'NWS',
            'publishedAt' => $p['sent'] ?? gmdate('c'),
            'description' => $p['description'] ?? null,
            'countries'   => isset($p['areaDesc']) ? [$p['areaDesc']] : [],
            'url'         => 'https://www.tsunami.gov/',
        ];
    }
    return ['items' => $out, 'status' => 'ok'];
}

// ── WHO Disease Outbreak News ─────────────────────────────────────────────────
function fetch_who() {
    $raw = http_get('https://www.who.int/api/news/diseaseoutbreaknews?$orderby=PublicationDateAndTime%20desc&$top=10');
    if (!$raw) return ['items' => [], 'status' => 'error'];
    $data = json_decode($raw, true);
    $out  = [];
    foreach ($data['value'] ?? [] as $d) {
        $url = isset($d['ItemDefaultUrl'])
            ? 'https://www.who.int/emergencies/disease-outbreak-news/item' . $d['ItemDefaultUrl']
            : null;
        $out[] = [
            'id'          => 'who-' . ($d['Id'] ?? md5($d['Title'] ?? '')),
            'title'       => $d['Title'] ?? 'Disease Outbreak News',
            'type'        => 'epidemic',
            'severity'    => 'medium',
            'source'      => 'WHO',
            'publishedAt' => $d['PublicationDateAndTime'] ?? gmdate('c'),
            'description' => null,
            'countries'   => [],
            'url'         => $url,
        ];
    }
    return ['items' => $out, 'status' => 'ok'];
}

// ── NASA EONET — single request (rate-limit safe) ─────────────────────────────
function _eonet_map($e) {
    $catMap = [
        'wildfires'    => 'wildfire',
        'severeStorms' => 'storm',
        'floods'       => 'flood',
        'drought'      => 'drought',
        'volcanoes'    => 'volcano',
        'earthquakes'  => 'earthquake',
        'seaLakeIce'   => 'other',
        'landslides'   => 'other',
        'dustHaze'     => 'other',
        'tempExtremes' => 'other',
        'snow'         => 'other',
    ];
    $catId     = $e['categories'][0]['id'] ?? '';
    $type      = isset($catMap[$catId]) ? $catMap[$catId] : classify_type($e['title'] ?? '');
    $geos      = $e['geometry'] ?? [];
    $latest    = !empty($geos) ? end($geos) : null;
    $url       = $e['sources'][0]['url'] ?? ($e['link'] ?? null);
    $catTitles = [];
    foreach ($e['categories'] ?? [] as $c) {
        if (!empty($c['title'])) $catTitles[] = $c['title'];
    }
    $severity = in_array($type, ['wildfire', 'storm', 'volcano'], true) ? 'high' : 'medium';
    return [
        'id'          => 'eonet-' . ($e['id'] ?? md5($e['title'] ?? '')),
        'title'       => $e['title'] ?? 'Unknown Event',
        'type'        => $type,
        'severity'    => $severity,
        'source'      => 'NASA EONET',
        'publishedAt' => isset($latest['date']) ? gmdate('c', strtotime($latest['date'])) : gmdate('c'),
        'description' => !empty($catTitles) ? implode(', ', $catTitles) : null,
        'countries'   => [],
        'url'         => $url,
    ];
}

function fetch_eonet() {
    $raw = http_get('https://eonet.gsfc.nasa.gov/api/v3/events?days=30&limit=50');
    if (!$raw) return ['items' => [], 'status' => 'error'];
    $data = json_decode($raw, true);
    $out  = [];
    foreach ($data['events'] ?? [] as $e) {
        $out[] = _eonet_map($e);
    }
    return ['items' => $out, 'status' => 'ok'];
}

// ── Aggregate ─────────────────────────────────────────────────────────────────
$usgs      = fetch_usgs();
$floods    = fetch_nws_floods();
$storms    = fetch_nws_storms();
$tsunami   = fetch_tsunami();
$who       = fetch_who();
$eonet     = fetch_eonet();

$results = [$usgs, $floods, $storms, $tsunami, $who, $eonet];
$names   = ['USGS', 'NWS Floods', 'NWS Storms', 'NWS Tsunami', 'WHO', 'NASA EONET'];

$events  = [];
$sources = [];
foreach ($results as $i => $r) {
    foreach ($r['items'] as $item) {
        $events[] = $item;
    }
    $sources[] = [
        'name'   => $names[$i],
        'status' => $r['status'],
        'count'  => count($r['items']),
        'error'  => null,
    ];
}

usort($events, function($a, $b) {
    return strtotime($b['publishedAt']) - strtotime($a['publishedAt']);
});

$payload = [
    'events'    => $events,
    'sources'   => $sources,
    'fetchedAt' => (int)(microtime(true) * 1000),
];

$json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
@file_put_contents($cacheFile, $json);

header('Content-Type: application/json; charset=utf-8');
echo $json;
